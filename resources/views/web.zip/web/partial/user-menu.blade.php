
@if( \Auth::check())
<section class="second-links">
    <div class="container">
        <ul class="menu-links second-menu-links" style="display: none; max-height: 400px; overflow: auto;">
            <!-- active class -->

            <li class="hoverTrigger">
                <a href="javascript:void(0)"><span class="deals-icons"></span>my deals <i class="fa fa-angle-down fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                <!-- drop down multilevel  -->
                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">Grid Style<i class="fa fa-angle-right fa-indicator"></i> <span class="label label-info">New</span><div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li><a href="listing.html">Listing Grid 1</a></li>
                            <li><a href="listing-1.html">Listing Grid 2</a></li>
                            <li><a href="listing-2.html">Listing Grid 3</a></li>
                            <li><a href="listing-7.html">Listing Featured <span class="label label-info">New</span></a></li>
                        </ul>
                    </li>
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">List Style<i class="fa fa-angle-right fa-indicator"></i> <div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li><a href="listing-3.html">List View 1</a></li>
                            <li><a href="listing-4.html">List View 2</a></li>
                            <li><a href="listing-5.html">List View 3</a></li>
                            <li><a href="listing-6.html">List View 4</a></li>
                        </ul>
                    </li>
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">Single Ad<i class="fa fa-angle-right fa-indicator"></i> <span class="label label-info">New</span><div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li><a href="single-page-listing.html">Single Ad Detail</a></li>
                            <li><a href="single-page-listing-featured.html">Ad (Featured) <span class="label label-info">New</span></a></li>
                            <li><a href="single-page-listing-2.html">Single Ad 2</a></li>
                            <li><a href="single-page-listing-3.html">Single Ad (Adsense)</a></li>
                            <li><a href="single-page-expired.html">Single Ad (Closed)</a></li>
                        </ul>
                    </li>
                    <li><a href="icons.html">Classified Icons </a></li>
                </ul>
            </li>
            <li class="hoverTrigger">
                <a href="javascript:void(0)"><span class="name-icons "></span>name <i class="fa fa-angle-down fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                <!-- drop down multilevel  -->
                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                    <li><a href="category-2.html">Modern Variation</a></li>
                    <li><a href="category-3.html">Minimal Variation</a></li>
                    <li><a href="category-4.html">Fancy Variation</a></li>

                    <li><a href="category-6.html">Flat Variation</a></li>
                </ul>
            </li>
            <li class="hoverTrigger">
                <a href="javascript:void(0)"><span class="comm-icons"></span>My Communication box <i class="fa fa-angle-down fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                <!-- drop down multilevel  -->
                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                    <li><a href="profile.html">User Profile</a></li>
                    <li><a href="profile-2.html">User Profile 2</a></li>
                    <li><a href="archives.html">Archives</a></li>
                    <li><a href="active-ads.html">Active Ads</a></li>
                    <li><a href="pending-ads.html">Pending Ads</a></li>
                    <li><a href="favourite.html">Favourite Ads</a></li>
                    <li><a href="messages.html">Message Panel</a></li>
                    <li><a href="deactive.html">Account Deactivation</a></li>
                </ul>
            </li>

            <li class="hoverTrigger">

                <a href="javascript:void(0)"><span class="control-icons"></span>My Control Panel <i class="fa fa-angle-down fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                <!-- drop down multilevel  -->
                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                    <li><a href="#">Item one</a></li>
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">Items Right Side <i class="fa fa-angle-right fa-indicator"></i> <div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li class="hoverTrigger">
                                <a href="javascript:void(0)"> <i class="fa fa-buysellads"></i> Level 2 <i class="fa fa-angle-right fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                                <!-- drop down third level -->
                                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                </ul>
                            </li>
                            <li class="hoverTrigger">
                                <a href="javascript:void(0)"> <i class="fa fa-dashcube"></i> Level 2 <i class="fa fa-angle-right fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                                <!-- drop down third level -->
                                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                </ul>
                            </li>
                            <li class="hoverTrigger">
                                <a href="javascript:void(0)"> <i class="fa fa-heartbeat"></i> Level 2 <i class="fa fa-angle-right fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                                <!-- drop down third level -->
                                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                </ul>
                            </li>
                            <li class="hoverTrigger">
                                <a href="javascript:void(0)"> <i class="fa fa-medium"></i> Level 2 <i class="fa fa-angle-right fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                                <!-- drop down third level -->
                                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                </ul>
                            </li>
                            <li class="hoverTrigger">
                                <a href="javascript:void(0)"> <i class="fa fa-leanpub"></i> Level 2 <i class="fa fa-angle-right fa-indicator"></i> <div class="mobileTriggerButton"></div></a>
                                <!-- drop down third level -->
                                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="#">Item 2</a></li>
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">Items Left Side <i class="fa fa-angle-left fa-indicator"></i> <div class="mobileTriggerButton"></div></a>
                        <!-- add class left-side -->
                        <ul class="drop-down-multilevel left-side effect-expand-top" style="transition: all 400ms ease;">
                            <li>
                                <a href="#"> <i class="fa fa-forumbee"></i> Level 2</a>
                            </li>
                            <li>
                                <a href="#"> <i class="fa fa-hotel"></i> Level 2</a>
                            </li>
                            <li>
                                <a href="#"> <i class="fa fa-automobile"></i> Level 2</a>
                            </li>
                            <li class="hoverTrigger">
                                <a href="javascript:void(0)"> <i class="fa fa-heartbeat"></i> Level 2 <i class="fa fa-plus fa-indicator"></i> <div class="mobileTriggerButton"></div></a>
                                <!--drop down second level-->
                                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                    <li><a href="#">Level 3</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#"> <i class="fa fa-bookmark"></i> Level 2</a>
                            </li>
                            <li>
                                <a href="#"> <i class="fa fa-bell"></i> Level 2</a>
                            </li>
                            <li>
                                <a href="#"> <i class="fa fa-soccer-ball-o"></i> Level 2</a>
                            </li>
                            <li>
                                <a href="#"> <i class="fa fa-life-ring"></i> Level 2</a>
                            </li>
                        </ul>
                    </li>
                    <li><a href="#">Item 4</a>
                    </li>
                </ul>
            </li>
            <li class="hoverTrigger">
                <a href="javascript:void(0)"><span class="business-icons"></span>Business Solutions <i class="fa fa-angle-down fa-indicator"></i><div class="mobileTriggerButton"></div></a>
                <!-- drop down multilevel  -->
                <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">Grid Style<i class="fa fa-angle-right fa-indicator"></i> <span class="label label-info">New</span><div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li><a href="listing.html">Listing Grid 1</a></li>
                            <li><a href="listing-1.html">Listing Grid 2</a></li>
                            <li><a href="listing-2.html">Listing Grid 3</a></li>
                            <li><a href="listing-7.html">Listing Featured <span class="label label-info">New</span></a></li>
                        </ul>
                    </li>
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">List Style<i class="fa fa-angle-right fa-indicator"></i> <div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li><a href="listing-3.html">List View 1</a></li>
                            <li><a href="listing-4.html">List View 2</a></li>
                            <li><a href="listing-5.html">List View 3</a></li>
                            <li><a href="listing-6.html">List View 4</a></li>
                        </ul>
                    </li>
                    <li class="hoverTrigger">
                        <a href="javascript:void(0)">Single Ad<i class="fa fa-angle-right fa-indicator"></i> <span class="label label-info">New</span><div class="mobileTriggerButton"></div></a>
                        <!-- drop down second level -->
                        <ul class="drop-down-multilevel effect-expand-top" style="transition: all 400ms ease;">
                            <li><a href="single-page-listing.html">Single Ad Detail</a></li>
                            <li><a href="single-page-listing-featured.html">Ad (Featured) <span class="label label-info">New</span></a></li>
                            <li><a href="single-page-listing-2.html">Single Ad 2</a></li>
                            <li><a href="single-page-listing-3.html">Single Ad (Adsense)</a></li>
                            <li><a href="single-page-expired.html">Single Ad (Closed)</a></li>
                        </ul>
                    </li>
                    <li><a href="icons.html">Classified Icons </a></li>
                </ul>
            </li>
            <li><a href="contact.html"><span class="add-icons"></span>Add new item </a></li>
            <li><a href="contact.html"><span class="help-icons"></span>help </a></li>
            <li><a href="contact.html"><span class="sett-icons"></span>settings </a></li>
        </ul>
    </div>
</section>

    @endif