<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
      <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
      <meta name="description" content="">
      <meta name="author" content="ScriptsBundle">
      <title>Jazeema</title>
      <!-- =-=-=-=-=-=-= Favicons Icon =-=-=-=-=-=-= -->
      <!-- <link rel="icon" href="images/favicon.ico" type="image/x-icon" /> -->
      <!-- =-=-=-=-=-=-= Mobile Specific =-=-=-=-=-=-= -->
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
       <meta name="csrf-token" content="{{ csrf_token() }}">

    @php
        preg_match('/([a-z]*)@/i', request()->route()->getActionName(), $matches);
    @endphp
    <title>{{ucfirst(request()->route()->getActionMethod())}} {{str_replace('Controller','',$matches[1])}} - {{setting('sitename_'.\DataLanguage::get())}} {{__('Jazeema')}}</title>

	<base href="{{asset('assets/website/assets/')}}" target="_blank">

    <!-- =-=-=-=-=-=-= Bootstrap CSS Style =-=-=-=-=-=-= -->
       <link rel="stylesheet" href="css/bootstrap.css">
      <!-- =-=-=-=-=-=-= Template CSS Style =-=-=-=-=-=-= -->
      <link rel="stylesheet" href="css/style.css">
      <!-- =-=-=-=-=-=-= Font Awesome =-=-=-=-=-=-= -->
      <link rel="stylesheet" href="css/font-awesome.css" type="text/css">
      <!-- =-=-=-=-=-=-= Flat Icon =-=-=-=-=-=-= -->
      <link href="css/flaticon.css" rel="stylesheet">
      <!-- =-=-=-=-=-=-= Et Line Fonts =-=-=-=-=-=-= -->
      <link rel="stylesheet" href="css/et-line-fonts.css" type="text/css">
      <!-- =-=-=-=-=-=-= Menu Drop Down =-=-=-=-=-=-= -->
      <link rel="stylesheet" href="css/forest-menu.css" type="text/css">
      <!-- =-=-=-=-=-=-= Animation =-=-=-=-=-=-= -->
      <link rel="stylesheet" href="css/animate.min.css" type="text/css">
      <!-- =-=-=-=-=-=-= Select Options =-=-=-=-=-=-= -->
      <link href="css/select2.min.css" rel="stylesheet" />
      <!-- =-=-=-=-=-=-= noUiSlider =-=-=-=-=-=-= -->
      <link href="css/nouislider.min.css" rel="stylesheet">
      <!-- =-=-=-=-=-=-= Listing Slider =-=-=-=-=-=-= -->
      <link href="css/slider.css" rel="stylesheet">
      <!-- =-=-=-=-=-=-= Owl carousel =-=-=-=-=-=-= -->
      <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
      <link rel="stylesheet" type="text/css" href="css/owl.theme.css">
      <!-- =-=-=-=-=-=-= Check boxes =-=-=-=-=-=-= -->
      <link href="skins/minimal/minimal.css" rel="stylesheet">
      <!-- =-=-=-=-=-=-= Responsive Media =-=-=-=-=-=-= -->
      <link href="css/responsive-media.css" rel="stylesheet">
      <!-- =-=-=-=-=-=-= Template Color =-=-=-=-=-=-= -->
      <link rel="stylesheet" id="color" href="css/colors/defualt.css">

       {{--<style href="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" ></style>--}}


       @yield('header')


</head>
  <body>
      <!-- =-=-=-=-=-=-= login Modal =-=-=-=-=-=-= -->
  <div class="modal fade modal-login" tabindex="-1" role="dialog" aria-hidden="true" id="login-preview">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-body">

                  <h2 class="login-head">{{__('login')}}</h2>
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                  <!-- content goes here -->
                  <form id="login_form">
                      <div class="form-group">
                          <label>{{__('Email')}}</label>
                          <input placeholder="Your Email" name="email" class="form-control" type="email">
                      </div>
                      <div class="form-group">
                          <label>{{__('Password')}}</label>
                          <input placeholder="Your Password" name="password" class="form-control" type="password">
                      </div>
                      {{--<div class="form-group">--}}
                          {{--<div class="row">--}}
                              {{--<div class="col-xs-12">--}}
                                  {{--<div class="skin-minimal">--}}
                                      {{--<ul class="list">--}}
                                          {{--<li>--}}
                                              {{--<input  type="checkbox" id="minimal-checkbox-1">--}}
                                              {{--<label for="minimal-checkbox-1">Remember Me</label>--}}
                                          {{--</li>--}}
                                      {{--</ul>--}}
                                  {{--</div>--}}
                              {{--</div>--}}
                          {{--</div>--}}
                      {{--</div>--}}
                      <button class="btn btn-theme btn-lg btn-block">{{__('Login With Us')}}</button>
                  </form>

              </div>
          </div>
      </div>
  </div>
  <!-- =-=-=-=-=-=-= login Modal =-=-=-=-=-=-= -->
  <!-- =-=-=-=-=-=-= signup Modal =-=-=-=-=-=-= -->
  <div class="modal fade modal-register" tabindex="-1" role="dialog" aria-hidden="true" id="register-preview">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-body">

                  <h2 class="login-head">{{__('Signup')}}</h2>
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                  <!-- content goes here -->
                  <form id="signupForm" method="post" enctype="multipart/form-data">
                      <div class="form-group {!! formError($errors,'type',true) !!}">
                              {!! Form::label('type', __('Type').':') !!}
                              {!! Form::select('type',['0'=>'Select Type','individual'=>__('Individual'),'company'=>__('company')],isset($result->id) ? $result->type:old('type'),['class'=>'form-control','id'=>'type_id','onChange'=>'changeType()']) !!}
                          {!! formError($errors,'type') !!}

                      </div>
                      <div id="select_type" style="display: none;">
                          <div class="form-group{!! formError($errors,'company_business',true) !!}">
                                  {!! Form::label('company_business', __('Company Business').':') !!}
                                  {!! Form::text('company_business',isset($result->id) ? $result->company_business:old('company_business'),['class'=>'form-control']) !!}

                              {!! formError($errors,'company_business') !!}
                          </div>

                          <div class="form-group{!! formError($errors,'company_name',true) !!}">
                              <div class="controls">
                                  {!! Form::label('company_name', __('Company Name').':') !!}
                                  {!! Form::text('company_name',isset($result->id) ? $result->company_name:old('company_name'),['class'=>'form-control']) !!}
                              </div>
                              {!! formError($errors,'company_name') !!}
                          </div>

                      </div>
                      <div class="form-group {!! formError($errors,'firstname',true) !!}">
                          <label for="firstname">{{__('First Name')}}</label>
                          <input placeholder="{{__('First Name')}}" class="form-control" type="text" name="firstname">
                          {!! formError($errors,'firstname') !!}
                      </div>
                      <div class="form-group {!! formError($errors,'lastname',true) !!}">
                          <label for="lastname">{{__('Last Name')}}</label>
                          <input placeholder="{{__('Last Name')}}" class="form-control" type="text" name="lastname">
                          {!! formError($errors,'lastname') !!}
                      </div>
                      <div class="form-group {!! formError($errors,'email',true) !!}">
                          <label for="email">{{__('Email')}}</label>
                          <input placeholder="{{__('Your Email')}}" class="form-control" type="email" name="email">
                          {!! formError($errors,'email') !!}
                      </div>
                      <div class="form-group {!! formError($errors,'password',true) !!}">
                          <label for="password"></label>
                          <input placeholder="{{__('Your Password')}}" class="form-control" type="password" name="password">
                          {!! formError($errors,'password') !!}
                      </div>
                      <div class="form-group {!! formError($errors,'password_confirmation',true) !!}">
                          <label for="password_confirmation">{{__('Confirm Password')}}</label>
                          <input placeholder="{{__('Confirm Password')}}" class="form-control" type="password" name="password_confirmation">
                          {!! formError($errors,'password_confirmation') !!}
                      </div>
                      <div class="form-group col-sm-6{!! formError($errors,'phone',true) !!}">
                          <div class="controls">
                              {!! Form::label('phone', __('Phone').':') !!}
                              {!! Form::number('phone',isset($result->id) ? $result->phone:old('phone'),['class'=>'form-control']) !!}
                          </div>
                          {!! formError($errors,'phone') !!}
                      </div>
                      <div class="form-group col-sm-6{!! formError($errors,'mobile',true) !!}">
                          <div class="controls">
                              {!! Form::label('mobile', __('Mobile').':') !!}
                              {!! Form::number('mobile',isset($result->id) ? $result->mobile:old('mobile'),['class'=>'form-control']) !!}
                          </div>
                          {!! formError($errors,'mobile') !!}
                      </div>
                      <div class="form-group{!! formError($errors,'gender',true) !!}">

                              {!! Form::label('gender', __('Gender').':') !!}
                              {!! Form::select('gender',['male'=>__('Male'),'female'=>__('Female')],isset($result->id) ? $result->gender:old('gender'),['class'=>'form-control']) !!}
                          {!! formError($errors,'gender') !!}
                      </div>
                      <div class="form-group custom-file-upload {!! formError($errors,'image',true) !!}" id="#bb">
                          <label for="image">Upload Image</label>
                          <input placeholder="Confirm Password" class="form-control" type="file" name="image">
                      </div>
                      <div class="form-group col-sm-12{!! formError($errors,'user_job_id',true) !!}">
                          <div class="controls">
                             
                              {!! Form::label('user_job_id', __('Select User Job')) !!}
                              {!! Form::select('user_job_id',['0'=>'Select User Job']+$userJobs,isset($result->id) ? $result->user_job_id:old('user_job_id'),['class'=>'form-control user_job_id','onChange'=>'get_attribute();']) !!}
                          </div>
                          {!! formError($errors,'user_job_id') !!}
                      </div>



                                                  <div id="attribute_div_list">

                                                      @if(isset($result->id))
                                                          @if($current_attribute)

                                                              @foreach($current_attribute as $key=>$value)
                                                                  {{--@foreach($v->attribute as $k=>$value)--}}
                                                                  {{--{{dd($value->attribute)}}--}}

                                                                  <div class="attribute_div_row attribute_div_row_{{$value->attribute->id}}">
                                                                      <div class="form-group col-sm-10{!! formError($errors,'attribute.'.$value->attribute->id,true) !!}">
                                                                          <div class="controls">
                                                                              {!! Form::label('attribute',$value->attribute->name_ar) !!}
                                                                              <div class="input-group input-group-lg">
                                                                                  @if($value->attribute->type == 'text')
                                                                                      {!! Form::text('attribute['.$value->attribute->id.']',$value->value,['id'=>'attribute_'.$value->attribute->id,'class'=>'form-control']) !!}
                                                                                  @elseif($value->type == 'textarea')
                                                                                      {!! Form::textarea('attribute['.$value->attribute->id.']',$value->value,['id'=>'attribute_'.$value->attribute->id,'class'=>'form-control']) !!}
                                                                                  @elseif($value->type == 'select')
                                                                                      {!! Form::select('attribute['.$value->attribute->id.']',[''=>__('Select Attribute')]+array_column( $value->attribute->values->toArray(),'name_ar','id'),$value->attribute->value,['id'=>'attribute_'.$value->attribute->id,'class'=>'form-control newselect2']) !!}
                                                                                  @elseif($value->attribute->type == 'multi-select')
                                                                                      <select name="attribute[{{$value->attribute->id}}][]"
                                                                                              id="" multiple
                                                                                              class="form-control newselect2">
                                                                                          <option value="">{{__('Select Attribute')}}</option>
                                                                                          @foreach($value->values()->select('*','name_'.\DataLanguage::get().' as name')->get() as $oneval )
                                                                                              <option @if(is_array(explode(',',$value->value)))  @if(in_array($oneval->id,explode(',',$value->value))) selected
                                                                                                      @endif  @endif value="{{$oneval->id}}">{{$oneval->name}}</option>
                                                                                          @endforeach
                                                                                      </select>
                                                                                  @endif


                                                                              </div>
                                                                          </div>
                                                                          {!! formError($errors,'attribute.'.$value->attribute->id.'.template_attribute') !!}
                                                                      </div>
                                                                  </div>

                                                              @endforeach
                                                              {{--@endforeach--}}
                                                          @endif

                                                      @endif
                                                  </div>


                      {{--<div class="form-group">--}}
                          {{--<div class="row">--}}
                              {{--<div class="col-xs-12">--}}
                                  {{--<div class="skin-minimal">--}}
                                      {{--<ul class="list">--}}
                                          {{--<li>--}}
                                              {{--<input  type="checkbox" id="minimal-checkbox-1">--}}
                                              {{--<label for="minimal-checkbox-1">I agree the terms of use</label>--}}
                                          {{--</li>--}}
                                      {{--</ul>--}}
                                  {{--</div>--}}
                              {{--</div>--}}
                          {{--</div>--}}
                      {{--</div>--}}
                      <button class="btn btn-theme btn-lg btn-block">Register</button>
                  </form>

              </div>
          </div>
      </div>
  </div>
  <!-- =-=-=-=-=-=-= signup Modal =-=-=-=-=-=-= -->
      <!-- =-=-=-=-=-=-= Transparent Header =-=-=-=-=-=-= -->
      <div class="transparent-header">
         <!-- Top Bar -->
         <div class="header-top">
            <div class="container">
               <div class="row">
                  <!-- Header Top Left -->
                  <div class="header-top-left col-md-12 col-sm-12 col-xs-12 hidden-xs">
                     <ul class="listnone">
                        @php   $itemCategories = ActiveParentCategories(8); @endphp
                        @if($itemCategories->isNotEmpty())

                         @foreach($itemCategories as $category)
                                 <li><a href="{{route('web.item.category',$category->{'slug_'.\DataLanguage::get()} )}}"><img src="{{img($category->icon)}}" alt="{{$category->name}}"> {{$category->name}} </a></li>
                         @endforeach
                         @endif
                         @php   $itemCategories = ActiveParentCategories(10,8); @endphp
                         @if($itemCategories->isNotEmpty())
                        <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="icons/9.png" alt=""> {{__('More')}} <span class="caret"></span></a>
                           <ul class="dropdown-menu">
                               @foreach($itemCategories as $category)
                              <li><a href="{{route('web.item.category',$category->{'slug_'.\DataLanguage::get()} )}}">{{$category->name}}</a></li>
                               @endforeach
                           </ul>
                        </li>
                         @endif
                     </ul>
                  </div>
               </div>
            </div>
         </div>
         <!-- Top Bar End -->
         <!-- Navigation Menu -->
         <div class="clearfix"></div>
         <!-- menu start -->
         <nav id="menu-1" class="mega-menu">
               <!-- menu list items container -->
               <section class="menu-list-items">
                  <div class="container">
                     <div class="row">
                        <div class="col-lg-12 col-md-12">
                           <!-- menu logo -->
                           <ul class="menu-logo col-md-2 no-padding">
                              <li>
                                 <a href="{{route('web.index')}}"><img src="{{asset('logo.png')}}" alt="logo"> </a>
                              </li>
                           </ul>
                           <!-- menu links -->
                           <ul class="menu-links">
                             <li class="dropdown" id="my-catg">
                                <a href="#" class="dropdown-toggle open-catg" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                 <img src="icons/menu.png" alt="">
                                </a>
                                <ul class="dropdown-menu drop-down-multilevel" id="urgent">
                                   <li>
                                     <a href="javascript:void(0)">aaaaaaaaa<i class="fa fa-angle-right fa-indicator"></i></a>
                                     <ul class="drop-down-multilevel">
                                       <li><a href="listing.html">Listing Grid 1</a></li>
                                       <li><a href="listing-1.html">Listing Grid 2</a></li>
                                       <li><a href="listing-2.html">Listing Grid 3</a></li>
                                     </ul>
                                   </li>
                                   <li><a href="#">bbbbbbbbb</a></li>
                                   <li><a href="#">ccccccccc</a></li>
                                   <li><a href="#">ddddddddd</a></li>
                                   <li><a href="#">eeeeeeeee</a></li>
                                </ul>
                             </li>

                                 </ul>
                                 <form class="submit-form search-form col-md-4 col-sm-8 col-xs-8" action="index.html" method="post">
                                   <div class="search-wrapper">
                                     <ul class="" style="display: inline-block;vertical-align: bottom;">
                                       <li class="dropdown">
                                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" id="sort1"><img src="icons/9.png" alt=""> Sorting by <span class="caret"></span></a>
                                          <ul class="dropdown-menu">
                                             <li><a href="#">aaaaaaaaa</a></li>
                                             <li><a href="#">bbbbbbbbb</a></li>
                                             <li><a href="#">ccccccccc</a></li>
                                             <li><a href="#">ddddddddd</a></li>
                                             <li><a href="#">eeeeeeeee</a></li>
                                          </ul>
                                       </li>
                                     </ul>
                                   <input class="form-control" placeholder="Search" type="text">
                                   </div>
                                 </form>
                                  <div class="other-drop no-padding">
                                    <ul class="">
                                      <li class="dropdown">
                                         <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" id="sort"><img src="icons/9.png" alt=""> Sorting by <span class="caret"></span></a>
                                         <ul class="dropdown-menu">
                                            <li><a href="#">aaaaaaaaa</a></li>
                                            <li><a href="#">bbbbbbbbb</a></li>
                                            <li><a href="#">ccccccccc</a></li>
                                            <li><a href="#">ddddddddd</a></li>
                                            <li><a href="#">eeeeeeeee</a></li>
                                         </ul>
                                      </li>
                                    </ul>
                                  </div>
                                  <!-- start profile -->
                                  @if(Auth()->check())
                                <div class="my-profile">
                                    <img src="{{img(Auth::user()->image,'users')}}" alt="">
                                    <span class="user-name">{{Auth::user()->fullname}}</span>
                                </div>
                                      @endif
                                  <ul class="right-links">
                                       @if(!auth()->check())
                                      <li><a href="#register-preview" data-toggle="modal">join</a></li>
                                          <li><a href="#login-preview" data-toggle="modal">login</a></li>

                                           @else
                                          <li><a href="{{route('web.user.logout')}}"  >logout</a></li>
                                      @endif
                                    <li class="for-lang">
                                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Language</a>
                                      <ul class="dropdown-menu">
                                         <li><a href="{{route('web.index','ar')}}">AR</a></li>
                                         <li><a href="{{route('web.index','en')}}">EN</a></li>
                                      </ul>
                                    </li>
                                    <li><a href="#">Get app</a></li>
                                  </ul>

                        </div>
                     </div>
                  </div>
               </section>

             @include('web.partial.user-menu')


             @php   $itemTypes = ActiveItemTypes(4); @endphp
             @if($itemTypes->isNotEmpty())
                 <section class="third-links">
                     <div class="container">
                         <div class="col-md-12">
                             <ul class="list-unstyled">
                        @foreach($itemTypes as $type)
                                     <li>
                                         <a target="_blank" href="{{route('web.item.type',$type->{'slug_'.\DataLanguage::get()} )}}"><img src="{{img($type->icon)}}" alt="{{$type->name}}">{{$type->name}}</a>
                                     </li>
                         @endforeach
                             </ul>
                         </div>
                     </div>
                 </section>
             @endif





            </nav>
         <!-- menu end -->
      </div>
      <!-- Navigation Menu End -->




                    @yield('content')

                  




 



      <!-- Back To Top -->
      <a href="#0" class="cd-top">Top</a>
      <!-- =-=-=-=-=-=-= JQUERY =-=-=-=-=-=-= -->

      <script src="js/jquery.min.js"></script>
      <script src="js/notify.min.js" ></script>

      <script src="js/masonary.min.js"></script>
      <!-- Bootstrap Core Css  -->
      <script src="js/bootstrap.min.js"></script>
      <!-- Jquery Easing -->
      <script src="js/easing.js"></script>
      <!-- Menu Hover  -->
      <script src="js/forest-megamenu.js"></script>
      <!-- Jquery Appear Plugin -->
      <script src="js/jquery.appear.min.js"></script>
      <!-- Numbers Animation   -->
      <script src="js/jquery.countTo.js"></script>
      <!-- Jquery Smooth Scroll  -->
      <script src="js/jquery.smoothscroll.js"></script>
      <!-- Jquery Select Options  -->
      <script src="js/select2.min.js"></script>
      <!-- noUiSlider -->
      <script src="js/nouislider.all.min.js"></script>
      <!-- Carousel Slider  -->
      <script src="js/carousel.min.js"></script>
      <script src="js/slide.js"></script>
      <!-- Image Loaded  -->
      <script src="js/imagesloaded.js"></script>
      <script src="js/isotope.min.js"></script>
      <!-- CheckBoxes  -->
      <script src="js/icheck.min.js"></script>
      <!-- Jquery Migration  -->
      <script src="js/jquery-migrate.min.js"></script>
      <!-- Sticky Bar  -->
      <script src="js/theia-sticky-sidebar.js"></script>
      <!-- Style Switcher -->
      <script src="js/color-switcher.js"></script>
      <!-- Template Core JS -->
      <script src="js/custom.js"></script>
      <script src="js/modernizr.js"></script>

      <script>

          function notify(status,msg){
           //   status[success,info,warn,error]
              $.notify(msg,status);
          }

          function like(itemID) {
              $.get('{{route('web.ajax.get',['type'=>'like'])}}',{item_id:itemID},function(out){
                      if(out.status == true){
                          $('#like_icon_'+itemID).css('color',out.color);
                      }else{
                          notify('error',out.msg);
                      }
                  },'json');
          }

          function share(itemID) {
              $.get('{{route('web.ajax.get',['type'=>'share'])}}',{item_id:itemID},function(out){
                  if(out.status == true){
                      notify('success',out.msg);
                      $('#share-now').modal('hide');
                  }else{
                      notify('error',out.msg);
                  }
              },'json');
          }

          function comment(itemID) {
              $.get('{{route('web.ajax.get',['type'=>'comment'])}}',
                  {item_id:itemID,comment:$('#comment_input_'+itemID).val()},function(out){
                  if(out.status == true){
                      notify('success',out.msg);
                      $('#comment_input_'+itemID).val('')

                  }else{
                      notify('error',out.msg);
                  }
              },'json');
          }

      $(document).ready(function() {
          
    

      {{--$("img").each(function() {--}}
      {{--// if image already loaded, we can check it's height now--}}
      {{--if (this.complete) {--}}
      {{--checkImg(this);--}}
      {{--} else {--}}
      {{--// if not loaded yet, then set load and error handlers--}}
      {{--$(this).load(function() {--}}
      {{--checkImg(this);--}}
      {{--}).error(function() {--}}
      {{--// img did not load correctly--}}
      {{--// set new .src here--}}

      {{--this.src = "{{asset('no_image.png')}}";--}}
      {{--});--}}

      {{--}--}}
      {{--});--}}
      });

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });


      {{--function like(itemID) {--}}

        {{--$.post('{{route('web.item.like')}}',{'id':itemID},function(out){--}}
            {{--if(out.status == true){--}}
                {{--$('#like'+itemID).css('color',out.data.color);--}}
            {{--}else{--}}
                {{--toastr('error',"{{__("Please Try Again Later")}}");--}}
            {{--}--}}
        {{--},'json')--}}
      {{--}--}}

   function get_attribute() {
          var user_job_id = $('#user_job_id').val();
          $.post('{{route('web.user.get-attribute')}}', {'user_job_id': user_job_id}, function (out) {
              if (out.status == false) {

                  $('#attribute_div_list').empty();
                  // toastr.error(out.msg, 'Error', {"closeButton": true});
              } else {
                  $('#attribute_div_list').html('');
                  for (var i = 0; i < out.data.length; i++) {
                      var attribute = out.data[i];
                      var drow = $('<div>').attr('class', 'attribute_row form-group');
                      drow.append($('<label>').html(attribute.name));

                      if (attribute.type == 'text') {
                          drow.append($('<input>', {name: 'attribute[' + attribute.id + ']',id:'attribute_'+attribute.id, class: 'form-control'}));
                      } else if (attribute.type == 'textarea') {
                          drow.append($('<textarea>', {
                              name: 'attribute[' + attribute.id + ']',
                              id: 'attribute_' + attribute.id,
                              class: 'form-control'
                          }));
                      } else if (attribute.type == 'select') {
                          var select = $('<select>', {
                              name: 'attribute[' + attribute.id + ']',
                              class: 'form-control',
                              style: 'width:100%',
                              id: 'attribute_' + attribute.id
                          });
                          if (attribute.values) {
                              var options = [];
                              for (var x = 0; x < attribute.values.length; x++) {
                                  var attr_value = attribute.values[x];
                                  options.push($('<option>', {value: attr_value.id}).html(attr_value.name));
                              }

                              drow.append(select.html(options));
                          }
                      }
                      else if (attribute.type == 'multi-select') {
                          var select = $('<select>', {
                              name: 'attribute[' + attribute.id + '][]',
                              class: 'form-control select2',
                              style: 'width:100%',
                              multiple: '',
                              id: 'attribute_' + attribute.id
                          });
                          if (attribute.values) {
                              var options = [];
                              for (var x = 0; x < attribute.values.length; x++) {
                                  var attr_value = attribute.values[x];
                                  options.push($('<option>', {value: attr_value.id}).html(attr_value.name));
                              }

                              drow.append(select.html(options));
                          }
                      }


                      $('#attribute_div_list').append(drow);
                      $('#attribute_' + attribute.id).select2();
                  }
              }

          }, 'json');
      }

          $('#login_form').submit(function (e) {
              e.preventDefault();
              var formData = new FormData(this);
              e.preventDefault();
              $.ajax({
                  type: "post",
                  url: '{{ route('web.user.login') }}',
                  {{--url: '{{ route('web.user.register', [$article]) }}',--}}
                  processData: false,
                  contentType: false,
                  data: formData,
                  success: function (out) {

                      if ( out.status == true) {

                          window.location = "{{route('web.user.myitems')}}";
                      }else {
                          notify(out.msg, 'Error', {"closeButton": true});

                      }
                  },
                  error: function (out) {

                          notify("ERROR", 'Error', {"closeButton": true});

                  }
              });



          });

      $('#signupForm').submit(function (e) {
          e.preventDefault();
          $('small').remove();
          var formData = new FormData(this);
          e.preventDefault();
          $.ajax({
              type: "post",
              url: '{{ route('web.user.register') }}',
              {{--url: '{{ route('web.user.register', [$article]) }}',--}}
              processData: false, contentType: false,
              data: formData,
              success: function (out) {
                  // alert(out.msg);
                  if ( out.status == true) {
                      window.location = "{{route('web.user.myitems')}}";
                   //   notify('success',out.msg);
                     // toastr.success(out.msg, 'Success', {"closeButton": true});
                      $('#signupForm')[0].reset();
                  }else {
                          $.each(out.data, function (index, value) {
                              var inputName = index.split(".");
                              if(inputName[1]) {

                                  $('#attribute_'+inputName[1]).after(' <small style="color:red"> field is required.</small>');

                              }else {
                                  $("input[name=" + index + "]").after(' <small style="color:red">' + value + '</small>');
                                  $("select[name=" + index + "]").after(' <small style="color:red">' + value + '</small>');
                              }
                            //  notify('error',value);

                                });

                  }
              },
              error: function (out) {
                  notify('ERROR');
              }
          });



      });
      
       function changeType(){
          var type= $('#type_id').val();
          console.log(type);
          if(type == 'company'){
              $('#select_type').show();
          }else{
              $('#select_type').hide();
          }
      }

      // function toastr(status,msg) {
      //     //status [success,info,warning,error]
      //     Command: toastr[status](msg);
      //  }
      </script>
                    @yield('footer')
                   


                    </body>
</html>