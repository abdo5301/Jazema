@extends('web.layouts')

@section('content')


    <!-- =-=-=-=-=-=-= Home Banner 2 End =-=-=-=-=-=-= -->
    <!-- =-=-=-=-=-=-= Main Content Area =-=-=-=-=-=-= -->
    <div class="main-content-area clearfix" style="   margin-top:@if( \Auth::check()) 190px; @else 90px; @endif "  >

        <!-- =-=-=-=-=-=-= Featured Ads =-=-=-=-=-=-= -->
        <section class="custom-padding">
            <!-- Main Container -->
            <div class="container">
                <!-- Row -->
                <div class="row">
                    <!-- Middle Content Box -->
                    <div class="col-md-12 col-xs-12 col-sm-12">
                        <div class="rows grid" id="items">




                        </div>

                    </div>

                    <div class="col-md-12 col-xs-12 col-sm-12" id="loading"  >
                        <img src="{{img('loading.gif')}}" alt="{{__('loading')}}...">
                    </div>

                    <!-- Middle Content Box End -->
                </div>


                <!-- Row End -->
            </div>
            <!-- Main Container End -->
        </section>

    </div>
    <!-- Main Content Area End -->

    <!-- Back To Top -->
    <a href="#0" class="cd-top">Top</a>
    {{--<!-- =-=-=-=-=-=-= login Modal =-=-=-=-=-=-= -->--}}
    {{--<div class="modal fade modal-login" tabindex="-1" role="dialog" aria-hidden="true" id="login-preview">--}}
        {{--<div class="modal-dialog">--}}
            {{--<div class="modal-content">--}}
                {{--<div class="modal-body">--}}

                    {{--<h2 class="login-head">login</h2>--}}
                    {{--<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>--}}
                    {{--<!-- content goes here -->--}}
                    {{--<form>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Email</label>--}}
                            {{--<input placeholder="Your Email" class="form-control" type="email">--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Password</label>--}}
                            {{--<input placeholder="Your Password" class="form-control" type="password">--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<div class="row">--}}
                                {{--<div class="col-xs-12">--}}
                                    {{--<div class="skin-minimal">--}}
                                        {{--<ul class="list">--}}
                                            {{--<li>--}}
                                                {{--<input  type="checkbox" id="minimal-checkbox-1">--}}
                                                {{--<label for="minimal-checkbox-1">Remember Me</label>--}}
                                            {{--</li>--}}
                                        {{--</ul>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<button class="btn btn-theme btn-lg btn-block">Login With Us</button>--}}
                    {{--</form>--}}

                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
    {{--<!-- =-=-=-=-=-=-= login Modal =-=-=-=-=-=-= -->--}}

    {{--<!-- =-=-=-=-=-=-= signup Modal =-=-=-=-=-=-= -->--}}
    {{--<div class="modal fade modal-register" tabindex="-1" role="dialog" aria-hidden="true" id="register-preview">--}}
        {{--<div class="modal-dialog">--}}
            {{--<div class="modal-content">--}}
                {{--<div class="modal-body">--}}

                    {{--<h2 class="login-head">Signup</h2>--}}
                    {{--<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>--}}
                    {{--<!-- content goes here -->--}}
                    {{--<form>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Register as</label>--}}
                            {{--<!-- <input placeholder="Your Email" class="form-control" type="email"> -->--}}
                            {{--<div class="skin-minimal">--}}
                                {{--<ul class="list">--}}
                                    {{--<li>--}}
                                        {{--<input tabindex="7" type="radio" id="minimal-radio-1" name="minimal-radio">--}}
                                        {{--<label  for="minimal-radio-1">Personal </label>--}}
                                    {{--</li>--}}
                                    {{--<li>--}}
                                        {{--<input tabindex="8" type="radio" id="minimal-radio-2" name="minimal-radio" checked>--}}
                                        {{--<label for="minimal-radio-2">Company</label>--}}
                                    {{--</li>--}}
                                {{--</ul>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Name</label>--}}
                            {{--<input placeholder="Your Name" class="form-control" type="text">--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Email</label>--}}
                            {{--<input placeholder="Your Email" class="form-control" type="email">--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Password</label>--}}
                            {{--<input placeholder="Your Password" class="form-control" type="password">--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<label>Confirm Password</label>--}}
                            {{--<input placeholder="Confirm Password" class="form-control" type="password">--}}
                        {{--</div>--}}
                        {{--<div class="form-group custom-file-upload" id="#bb">--}}
                            {{--<label>Upload Image</label>--}}
                            {{--<input placeholder="Confirm Password" class="form-control" type="file">--}}
                        {{--</div>--}}
                        {{--<div class="form-group">--}}
                            {{--<div class="row">--}}
                                {{--<div class="col-xs-12">--}}
                                    {{--<div class="skin-minimal">--}}
                                        {{--<ul class="list">--}}
                                            {{--<li>--}}
                                                {{--<input  type="checkbox" id="minimal-checkbox-1">--}}
                                                {{--<label for="minimal-checkbox-1">I agree the terms of use</label>--}}
                                            {{--</li>--}}
                                        {{--</ul>--}}
                                    {{--</div>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<button class="btn btn-theme btn-lg btn-block">Register</button>--}}
                    {{--</form>--}}

                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
    {{--<!-- =-=-=-=-=-=-= signup Modal =-=-=-=-=-=-= -->--}}

    {{--<!-- =-=-=-=-=-=-= share Modal =-=-=-=-=-=-= -->--}}
    {{--<div class="modal fade modal-share" tabindex="-1" role="dialog" aria-hidden="true" id="share-now">--}}
        {{--<div class="modal-dialog">--}}
            {{--<div class="modal-content">--}}
                {{--<div class="modal-body">--}}
                    {{--<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>--}}
                    {{--<!-- content goes here -->--}}
                    {{--<div class="row">--}}
                        {{--<div class="col-md-6 col-sm-6">--}}
                            {{--<div class="lefty">--}}
                                {{--<h6><i class="fa fa-share-alt"></i>Share item to website now</h6>--}}
                                {{--<button class="btn btn-blue margin-bottom-10" type="button">share item now</button>--}}
                                {{--<img src="images/share.png" alt="">--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<div class="col-md-6 col-sm-6">--}}
                            {{--<div class="lefty shares">--}}
                                {{--<h6><i class="fa fa-share-alt"></i>Share item to social media</h6>--}}
                                {{--<button class="btn btn-blue margin-bottom-10 fb" type="button">facebook</button>--}}
                                {{--<button class="btn btn-blue margin-bottom-10 tw" type="button">twitter</button>--}}
                                {{--<button class="btn btn-blue margin-bottom-10 inst" type="button">instagram</button>--}}
                                {{--<button class="btn btn-blue margin-bottom-10 pint" type="button">pinterest</button>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}

                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}

    {{--<!-- =-=-=-=-=-=-= share Modal =-=-=-=-=-=-= -->--}}


@endsection


@section('footer')


    <script>
        $(document).ready(function(){

            runGetItems();

        });

        function runGetItems(){
            $("#loading").show();

            $.post("{{route('web.item.get-items')}}",{'offset':$("#items .item").length}, function( items ) {
           if(items.status == true){
             //  console.log(items);
            for(var i =0;i<= items.data.length;i++){
                var item = items.data[i];
              //  console.log(item);
                $("#items").append(item);
            }
               $("#loading").hide();
           }else{
               $("#loading").html("{{__("No More Items")}}");
           }
            },'json');
        }





        // extension:
        $.fn.scrollEnd = function(callback, timeout) {
            $(this).scroll(function(){
                var $this = $(this);
                if ($this.data('scrollTimeout')) {
                    clearTimeout($this.data('scrollTimeout'));
                }
                $this.data('scrollTimeout', setTimeout(callback,timeout));
            });
        };

        // how to call it (with a 1000ms timeout):
        $(window).scrollEnd(function(){
            runGetItems()
        }, 1000);
    </script>

    @endsection