@extends('web.layouts')

@section('content')


    <!-- start carousel -->
    <div class="background-rotator def-margin">
        <!-- slider start-->
        <div class="owl-carousel owl-theme background-rotator-slider">
            <!-- Slide -->
            <div class="item linear-overlay"><img src="images/slider/4.jpg" alt=""></div>
            <!-- Slide -->
            <div class="item linear-overlay"><img  src="images/slider/2.jpg" alt=""></div>
            <!-- Slide -->
            <div class="item linear-overlay"><img src="images/slider/3.jpg" alt=""></div>
        </div>
    </div>


    <!-- start about banner -->
    <section id="home-content">
        <div class="container">
            <div class="about-sec">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12 about">
                        <div class="l-shadow"></div>
                        <div class="r-shadow"></div>
                        <div class="col-md-6 col-sm-6 about-content">
                            <img src="icons/logo.png" alt="">
                            <p class="line-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            <a href="#" class="btn btn-primary btn-more">Know More</a>
                        </div>
                        <div class="col-md-6 col-sm-6 hidden-xs">
                            <div class="r-img">
                                <img src="images/about.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="services">
                <div class="ser-heading text-center">
                    <span class="before-head"></span>
                    <h2>services</h2>
                </div>
                <div class="ser-body">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="ser-item text-center">
                                <img src="images/3.png" alt="">
                                <h3>this is title for item</h3>
                                <h6>full width & boxed version</h6>
                                <p class="line2-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="ser-item text-center">
                                <img src="images/3.png" alt="">
                                <h3>this is title for item</h3>
                                <h6>full width & boxed version</h6>
                                <p class="line2-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="ser-item text-center">
                                <img src="images/3.png" alt="">
                                <h3>this is title for item</h3>
                                <h6>full width & boxed version</h6>
                                <p class="line2-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="ser-item text-center">
                                <img src="images/3.png" alt="">
                                <h3>this is title for item</h3>
                                <h6>full width & boxed version</h6>
                                <p class="line2-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="ser-item text-center">
                                <img src="images/3.png" alt="">
                                <h3>this is title for item</h3>
                                <h6>full width & boxed version</h6>
                                <p class="line2-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="ser-item text-center">
                                <img src="images/3.png" alt="">
                                <h3>this is title for item</h3>
                                <h6>full width & boxed version</h6>
                                <p class="line2-clamp">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section id="high_rank">
        <div class="container">
            <div class="hr-items">
                <div class="text-center">
                    <span class="before-head"></span>
                    <h2>high rank items</h2>
                </div>
                <!-- Middle Content Box -->
                <div class="col-md-12 col-xs-12 col-sm-12">
                    <div class="row">
                        <div class="featured-slider owl-carousel owl-theme">
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/car-3.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">2017 Honda Civic EX</a>
                                                <span class="user-r">Rank <num>#1</num></span>
                                            </h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/mob-2.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Sony Xperia Z5 </a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/house-5.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Cras ut eleifend quam</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/car-5.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Audi A7 3.0T quattro Prestige</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/lap-2.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Sony Vaio Pro 13 Ultrabook</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/spo-3.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Vestibulum est nunc</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/fur-3.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html"> Pedding design bed set  </a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/spo-5.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Cras ut eleifend quam</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/car-4.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">2007 BMW 3 Series 335i</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Middle Content Box End -->
            </div>
            <div class="clearfix"></div>
            <!-- start high rank users -->

            <div class="hr-users">
                <div class="text-center">
                    <span class="before-head"></span>
                    <h2>high rank users</h2>
                </div>
                <!-- Middle Content Box -->
                <div class="col-md-12 col-xs-12 col-sm-12 marg-top">
                    <div class="row">
                        <div class="high-rank-user owl-carousel owl-theme">
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/car-3.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">2017 Honda Civic EX</a>
                                                <span class="user-r">Rank <num>#1</num></span>
                                            </h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/mob-2.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Sony Xperia Z5 </a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/house-5.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Cras ut eleifend quam</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/car-5.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Audi A7 3.0T quat</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/lap-2.jpg">
                                            <!-- View Details --><a href="" class="view-details">View Details</a>
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Sony Vaio Pro </a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/spo-3.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Vestibulum est</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/fur-3.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html"> Pedding design</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/spo-5.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">Cras ut ele</a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-md-12 col-xs-12 col-sm-12 clearfix">
                                    <!-- Ad Box -->
                                    <div class="category-grid-box">
                                        <!-- Ad Img -->
                                        <div class="category-grid-img">
                                            <img class="img-responsive" alt="" src="images/posting/car-4.jpg">
                                        </div>
                                        <!-- Ad Img End -->
                                        <div class="short-description">
                                            <h3><a title="" href="single-page-listing.html">2007 BMW </a><span class="user-r">Rank <num>#1</num></span></h3>
                                        </div>
                                    </div>
                                    <!-- Ad Box End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Middle Content Box End -->
            </div>
        </div>
    </section>
    <section id="contact-sec">
        <div class="row">
            <div class="col-md-6">
                <div class="cont-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d13809.10198898178!2d31.29124615!3d30.0862953!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2seg!4v1525526641842" width="" height="" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-md-6">
                <div class="cont-details">
                    <h2>contacts</h2>
                    <ol class="list-unstyled">
                        <li>
                            <span><i class="fa fa-map-marker"></i></span>
                            jeddah - saudi arabia
                        </li>
                        <li>
                            <span><i class="fa fa-map-marker"></i></span>
                            jeddah - saudi arabia
                        </li>
                        <li>
                            <span><i class="fa fa-map-marker"></i></span>
                            jeddah - saudi arabia
                        </li>
                    </ol>

                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-xs-12">
                                <div class="form-group">
                                    <input type="text" placeholder="Name" id="name" name="name" class="form-control" required="">
                                </div>
                                <div class="form-group">
                                    <input type="email" placeholder="Email" id="email" name="email" class="form-control" required="">
                                </div>
                                <div class="form-group">
                                    <textarea cols="12" rows="7" placeholder="Message..." id="message" name="message" class="form-control" required=""></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <button class="btn btn-theme" type="submit">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4>About Jazeema</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="col-md-6 col-sm-6">
                        <h4>contact us</h4>
                        <ol class="list-unstyled">
                            <li>+9754879312</li>
                            <li>mail@jazeema.com</li>
                            <li>find us on map</li>
                            <li>
                                <i class="fa fa-facebook"></i><i class="fa fa-twitter"></i><i class="fa fa-instagram"></i>
                            </li>
                        </ol>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <h4>links</h4>
                        <ol class="list-unstyled">
                            <li>contact us</li>
                            <li>about us</li>
                            <li>site-map</li>
                            <li>Home Page</li>
                            <li>Add item</li>
                            <li>login</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="down-footer">
        <p class="text-center">All rights reserved to jazeema &copy 2018</p>
    </div>

@endsection
