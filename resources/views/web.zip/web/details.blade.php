@extends('web.layouts')

@section('content')
<!-- =-=-=-=-=-=-= Home Banner 2 End =-=-=-=-=-=-= -->
<!-- =-=-=-=-=-=-= Main Content Area =-=-=-=-=-=-= -->
<div class="main-content-area reset clearfix">

    <!-- =-=-=-=-=-=-= Featured Ads =-=-=-=-=-=-= -->
    <section class="item-details">
        <!-- Main Container -->
        <div class="container">
            <!-- Row -->
            <div class="row">
                <div class="item col-md-4">
                    <div class="clearfix">

                        <h5 class="item-title">
                            <a >{{$item->{'name'.\DataLanguage::get()} }}</a>
                        </h5>
                        <!-- Ad Box -->
                        <div class="category-grid-box">
                            @if($item->upload->isNotEmpty())
                            <!-- Ad Img -->
                            <div class="category-grid-img">
                                <div class="itm-overlay-top"></div>
                                <div class="itm-overlay-bott"></div>
                                <!-- <img class="img-responsive" alt="" src="images/asas.png"> -->
                                <div class="owl-carousel owl-theme single-details">
                                    @foreach($item->upload as $img)
                                    <!-- Slide -->
                                    <div class="item"><img src="{{img($img->path)}}" alt="{{$img->title}}"></div>
                                   @endforeach
                                </div>
                                <span class="itm-views"><i class="fa fa-eye"></i> {{$item->views}}</span>
                                <span class="itm-from"><img width="24px" height="24px" src="{{img($item->item_type->icon)}}" alt=""></span>
                                <span class="itm-price">{{$item->price}} {{setting('currency')}}</span>
                                {{--<a href="" class="view-details">View Details</a>--}}
                            </div>
                            <!-- Ad Img End -->
                            @endif
                            <div class="short-description">
                                <!-- Ad Category -->
                                <div class="category-title">
                                <span>
                                 <a href="{{route('web.item.category',$item->item_category->id)}}" class="cat-first">{{$item->item_category->name}}</a>
                                    @if($item->item_category->parent_id)
                                        <a href="#">{{$item->item_category->parent->{'name_'.\App\Libs\DataLanguage::get()} }}</a>
                                    @endif
                                </span>
                                </div>
                                <!-- no of social interactions -->
                                <ul class="list-unstyled social-rate">
                                    <li>
                                        <a href="javascript:;" onclick="like('{{$item->id}}')">
                                            <i id="like_icon_{{$item->id}}" style=" @if($item->AuthLiked == true) color:#3aa4c1;  @else color:#cccccc; @endif" class="fa fa-thumbs-up"></i>
                                            <span class="likes">{{$item->like}}</span>
                                        </a>
                                    </li>
                                    <li>
                                        <i style=" @if($item->AuthCommented) color:#3aa4c1;  @else color:#cccccc; @endif" class="fa fa-comments"></i>
                                        <span class="comments">{{$item->comments}}</span>
                                    </li>
                                    <li>
                                        <a href="#share-now" data-toggle="modal">
                                            <i  id="share_icon_{{$item->id}}" class="fa fa-share-alt"></i>
                                            <span class="share">{{$item->share}}</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#deal-now" data-toggle="modal">
                                            <img  @if($item->AuthDealed)src="images/deel.png" @else src="images/not-deal.png" @endif alt="">
                                            <span class="deeels">{{$item->deals}}</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <!-- short description -->
                            <div class="itm-desc line-clamp">
                                <p class="">{{$item->{'description'.\DataLanguage::get()} }}</p>
                            </div>
                            <!-- Addition Info -->
                            {{--<div class="ad-btns">--}}
                                {{--<ul>--}}
                                    {{--<li>--}}
                                        {{--<a href="#"><img src="images/pub.png" alt="">Publish</a>--}}
                                    {{--</li>--}}
                                    {{--<li>--}}
                                        {{--<a href="#"><img src="images/sav.png" alt=""> save</a>--}}
                                    {{--</li>--}}
                                {{--</ul>--}}
                            {{--</div>--}}
                                <div class="input-group post-comment">
                                  <span class="input-group-addon" id="basic-addon1">
                                    <a href="javascript:;" onclick="comment('{{$item->id}}')" class="submit-comment"><i class="fa fa-comments"></i></a>
                                  </span>
                                    <input type="text" class="form-control" id="comment_input_{{$item->id}}" placeholder="{{__('Comment')}}" aria-describedby="basic-addon1">
                                </div>
                        </div>
                        <!-- Ad Box End -->
                    </div>
                    <div class="tabs-in-branches">
                        <h3>Other Branches</h3>
                        {{--<div class="panel-heading">--}}
                            {{--<ul class="nav nav-tabs">--}}
                                {{--<li class="active"><a href="#tab11" data-toggle="tab" aria-expanded="true">1</a></li>--}}
                                {{--<li class=""><a href="#tab22" data-toggle="tab" aria-expanded="false">2</a></li>--}}
                                {{--<li class=""><a href="#tab33" data-toggle="tab" aria-expanded="false">3</a></li>--}}
                                {{--<li class=""><a href="#tab44" data-toggle="tab" aria-expanded="false">4</a></li>--}}
                                {{--<li class=""><a href="#tab44" data-toggle="tab" aria-expanded="false">5</a></li>--}}
                            {{--</ul>--}}
                        {{--</div>--}}
                        <div class="panel with-nav-tabs panel-default">
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade active in" id="tab11">
                                        <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d13809.10198898178!2d31.29124615!3d30.0862953!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2seg!4v1524869525493" frameborder="0" style="border:0" allowfullscreen></iframe>
                                    </div>
                                    {{--<div class="tab-pane fade" id="tab22">--}}
                                        {{--4646464646--}}
                                    {{--</div>--}}
                                    {{--<div class="tab-pane fade" id="tab33">--}}
                                        {{--4646464646--}}
                                    {{--</div>--}}
                                    {{--<div class="tab-pane fade" id="tab44">--}}
                                        {{--4646464646--}}
                                    {{--</div>--}}
                                    {{--<div class="tab-pane fade" id="tab55">--}}
                                        {{--4646464646--}}
                                    {{--</div>--}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="media item-d-media">
                        <div class="media-left">
                            <a href="{{route('web.user.profile',$item->user->slug)}}">
                                <img class="media-object" src="{{img($item->user->image,'users')}}" alt="{{$item->user->FullName}}">
                            </a>
                        </div>
                        <div class="media-body">
                            <h6 class="media-heading logo-name">{{$item->user->FullName}}</h6>
                            {{--<p>this is slogan</p>--}}
                            <p class="date">{{date('Y/m/d',strtotime($item->created_at))}}
                                {{--<span class="time" style="margin-left: 10px;">23:00</span>--}}
                            </p>
                        </div>
                    </div>
                    <div class="contact-via">
                        <ul>
                            @if(!empty($item->user->mobile))
                            <li>
                                <a href="tel:{{$item->user->mobile}}"><span><i class="fa fa-phone"></i></span>{{$item->user->mobile}}</a>
                            </li>
                            @endif
                            <li>
                                <a href="mailto:{{$item->user->email}}"><span><i class="fa fa-envelope"></i></span>{{__('contact via mail')}}</a>
                            </li>
                            <li>
                                <a href="{{route('web.user.profile',$item->user->slug)}}"><span><i class="fa fa-user"></i></span>{{__('visit profile')}}</a>
                            </li>
                            <li>
                                <a href="{{route('web.user.profile',$item->user->slug)}}"><span><i class="fa fa-user"></i></span>{{__('Number of projects')}}({{$item->user->items()->count()}})</a>
                            </li>
                            <li>
                                <a href="{{route('web.user.profile',$item->user->slug)}}"><span><i class="fa fa-user"></i></span>{{__('last update')}}({{$item->user->updated_at}})</a>
                            </li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                    <div class="tabs-in-details">
                        <div class="panel-heading">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#tab1default" data-toggle="tab" aria-expanded="true">Messages</a></li>
                                <li class=""><a href="#tab2default" data-toggle="tab" aria-expanded="false">Mail</a></li>
                            </ul>
                        </div>
                        <div class="panel with-nav-tabs panel-default">
                            <div class="panel-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade active in" id="tab1default">
                                        <div class="inline-mess">
                                            <ul class="messages">

                                                <li class="my-message clearfix">
                                                    <figure class="profile-picture">
                                                        <img src="images/users/1.jpg" class="img-circle" alt="Profile Pic">
                                                    </figure>
                                                    <div class="message">
                                                        With that budget we can make something pretty powerful. As soon as I get to the office we can start the team briefing!
                                                        <div class="time"><i class="fa fa-clock-o"></i> Today 9:12 AM</div>
                                                    </div>
                                                </li>

                                                <li class="friend-message clearfix">
                                                    <figure class="profile-picture">
                                                        <img src="images/users/2.jpg" class="img-circle" alt="Profile Pic">
                                                    </figure>
                                                    <div class="message">
                                                        Absolutely! Can't wait to get started!
                                                        <div class="time"><i class="fa fa-clock-o"></i> Today 9:14 AM</div>
                                                    </div>
                                                </li>

                                                <li class="my-message clearfix">
                                                    <figure class="profile-picture">
                                                        <img src="images/users/1.jpg" class="img-circle" alt="Profile Pic">
                                                    </figure>
                                                    <div class="message">
                                                        I am just grabbing the coffee and doughnuts. I will be at the office ASAP.
                                                        <div class="time"><i class="fa fa-clock-o"></i> Today 9:17 AM</div>
                                                    </div>
                                                </li>
                                                <li class="friend-message clearfix">
                                                    <figure class="profile-picture">
                                                        <img src="images/users/2.jpg" class="img-circle" alt="Profile Pic">
                                                    </figure>
                                                    <div class="message">
                                                        Sure. We are wrapping up the previous project, you have some time.
                                                        <div class="time"><i class="fa fa-clock-o"></i> Today 9:18 AM</div>
                                                    </div>
                                                </li>
                                                <li class="my-message clearfix">
                                                    <figure class="profile-picture">
                                                        <img src="images/users/1.jpg" class="img-circle" alt="Profile Pic">
                                                    </figure>
                                                    <div class="message">
                                                        Alrighty, cool!
                                                        <div class="time"><i class="fa fa-clock-o"></i> Today 9:17 AM</div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <form role="form" class="">
                                                <div class="form-group">
                                                    <input style="width: 100%" placeholder="Type a message here..." class="form-control" type="text">
                                                </div>
                                                <button class="btn btn-theme" type="submit">Send</button>
                                            </form>
                                        </div>
                                        <div class="inline-map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d13809.10198898178!2d31.29124615!3d30.0862953!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2seg!4v1524869525493" frameborder="0" style="border:0" allowfullscreen></iframe>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="tab2default">
                                        <form role="form" class="mail-form">
                                            <div class="form-group">
                                                <input style="width: 100%" placeholder="Full name" class="form-control" type="text">
                                                <input style="width: 100%" placeholder="Email" class="form-control" type="email">
                                                <input style="width: 100%" placeholder="Phone number" class="form-control" type="tel">
                                            </div>
                                            <button class="btn btn-theme" type="submit">Send</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="txt-about">
                        <h3>{{__('About')}}</h3>
                        <p>{{$item->user->about}}</p>
                    </div>
                    <div class="tags">
                        <ul>
                            @if(!empty($item->user->categories()))
                            <li>
                                <span class="tags-title">Categories</span>
                                @foreach ($item->user->categories() as $row)
                                <span class="cat-links"><a href="{{route('web.item.category',$row->{'slug_'.\DataLanguage::get() } ) }}">{{$row->{'name_'.\DataLanguage::get() } }}</a></span>
                                @endforeach
                            </li>
                            @endif
                            {{--<li>--}}
                                {{--<span class="tags-title">Payment</span>--}}
                                {{--<span class="pay">--}}
                            {{--<img src="images/pay.png" alt="">--}}
                          {{--</span>--}}
                                {{--<span class="pay" style="vertical-align: -webkit-baseline-middle;">--}}
                            {{--<img src="images/amz.png" alt="">--}}
                          {{--</span>--}}
                            {{--</li>--}}
                            {{--<li>--}}
                                {{--<span class="tags-title">Opening Hours</span>--}}
                                {{--<span>from <tag>8:00 AM</tag></span>--}}
                                {{--<span>to <tag>5:00 PM</tag></span>--}}
                            {{--</li>--}}
                            {{--<li>--}}
                                {{--<span class="tags-title">Other Contacts</span>--}}
                                {{--<span>+9752485221112</span>--}}
                            {{--</li>--}}
                            <li>
                                <span class="tags-title">{{__('Other links')}}</span>
                                @if(!empty($item->user->facebook))
                                <span class="tag-social"><a href="{{$item->user->facebook}}"><i class="fa fa-facebook"></i></a></span>
                                @endif
                                @if(!empty($item->user->twitter))
                                    <span class="tag-social"><a href="{{$item->user->twitter}}"><i class="fa fa-twitter"></i></a></span>
                                @endif
                                @if(!empty($item->user->google))
                                    <span class="tag-social"><a href="{{$item->user->google}}"><i class="fa fa-google"></i></a></span>
                                @endif
                                @if(!empty($item->user->instagram))
                                    <span class="tag-social"><a href="{{$item->user->instagram}}"><i class="fa fa-instagram"></i></a></span>
                                @endif
                                @if(!empty($item->user->pinterest))
                                    <span class="tag-social"><a href="{{$item->user->pinterest}}"><i class="fa fa-pinterest"></i></a></span>
                                @endif
                                 @if(!empty($item->user->linkedin))
                                    <span class="tag-social"><a href="{{$item->user->linkedin}}"><i class="fa fa-linkedin"></i></a></span>
                                @endif

                            </li>
                        </ul>
                        <ul class="list-unstyled social-rate inside-about">
                            <li>
                                <i class="fa fa-thumbs-up"></i>
                                <span class="likes">40</span>
                            </li>
                            <li>
                                <i class="fa fa-comments"></i>
                                <span class="comments">24</span>
                            </li>
                            <li>
                                <i class="fa fa-share-alt"></i>
                                <span class="share">14</span>
                            </li>
                            <li>
                                <img src="images/deel.png" alt="">
                                <span class="deeels">7</span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6" style="padding-left: 0">
                        <div class="category-grid-img ddd">
                            <!-- <img class="img-responsive" alt="" src="images/asas.png"> -->
                            <div class="owl-carousel owl-theme single-details">
                                <!-- Slide -->
                                <div class="item"><img src="images/single-page/7.jpg" alt=""></div>
                                <!-- Slide -->
                                <div class="item"><img  src="images/single-page/8.jpg" alt=""></div>
                                <!-- Slide -->
                                <div class="item"><img  src="images/single-page/9.jpg" alt=""></div>
                                <!-- Slide -->
                                <div class="item"><img  src="images/single-page/10.jpg" alt=""></div>
                            </div>
                        </div>
                    </div>
                    <div class="input-group post-comment col-md-12">
                      <span class="input-group-addon" id="basic-addon1">
                        <a href="#" class="submit-comment"><i class="fa fa-comments"></i></a>
                      </span>
                        <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                    </div>
                </div>
            </div>


            <div class="rows grid">
                <div class="item col-md grid-sizer grid-item">
                    <div class="clearfix">
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object" src="images/profile.png" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading logo-name">ibrahim elmajed</h6>
                                <p class="date">23/12/2018<span class="time" style="margin-left: 10px;">23:00</span></p>
                            </div>
                        </div>
                        <h5 class="item-title">
                            <a href="#">a recent company for trading</a>
                        </h5>
                        <!-- Ad Box -->
                        <div class="category-grid-box">
                            <!-- Ad Img -->
                            <div class="category-grid-img">
                                <div class="itm-overlay-top"></div>
                                <div class="itm-overlay-bott"></div>
                                <img class="img-responsive" alt="" src="images/asas.png">
                                <span class="itm-views"><i class="fa fa-eye"></i> 250</span>
                                <span class="itm-from"><img src="icons/4.png" alt=""></span>
                                <span class="itm-price">1000000$</span>
                                <a href="" class="view-details">View Details</a>
                            </div>
                            <!-- Ad Img End -->
                            <div class="short-description">
                                <!-- Ad Category -->
                                <div class="category-title">
                                <span>
                                  <a href="#" class="cat-first">real estate </a>
                                  <a href="#">real estate </a>
                                </span>
                                </div>
                                <!-- no of social interactions -->
                                <ul class="list-unstyled social-rate">
                                    <li>
                                        <i class="fa fa-thumbs-up"></i>
                                        <span class="likes">40</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-comments"></i>
                                        <span class="comments">24</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-share-alt"></i>
                                        <span class="share">14</span>
                                    </li>
                                    <li>
                                        <img src="images/deel.png" alt="">
                                        <span class="deeels">7</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- short description -->
                            <div class="itm-desc line-clamp">
                                <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                            </div>
                            <!-- Addition Info -->
                            <div class="ad-btns">
                                <ul>
                                    <li>
                                        <a href="#"><img src="images/pub.png" alt="">Publish</a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="images/sav.png" alt=""> save</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="input-group post-comment">
                             <span class="input-group-addon" id="basic-addon1">
                               <a href="#" class="submit-comment"><i class="fa fa-comments"></i></a>
                             </span>
                                <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <!-- Ad Box End -->
                    </div>
                </div>
                <div class="item col-md grid-sizer grid-item">
                    <div class="clearfix">
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object" src="images/profile.png" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading logo-name">ibrahim elmajed</h6>
                                <p class="date">23/12/2018<span class="time" style="margin-left: 10px;">23:00</span></p>
                            </div>
                        </div>
                        <h5 class="item-title">
                            <a href="#">a recent company for trading</a>
                        </h5>
                        <!-- Ad Box -->
                        <div class="category-grid-box">
                            <!-- Ad Img -->
                            <div class="category-grid-img">
                                <div class="itm-overlay-top"></div>
                                <div class="itm-overlay-bott"></div>
                                <img class="img-responsive" alt="" src="images/1.jpg">
                                <span class="itm-views"><i class="fa fa-eye"></i> 250</span>
                                <span class="itm-from"><img src="icons/4.png" alt=""></span>
                                <span class="itm-price">1000000$</span>
                                <a href="" class="view-details">View Details</a>
                            </div>
                            <!-- Ad Img End -->
                            <div class="short-description">
                                <!-- Ad Category -->
                                <div class="category-title">
                                <span>
                                  <a href="#" class="cat-first">real estate </a>
                                  <a href="#">real estate </a>
                                </span>
                                </div>
                                <!-- no of social interactions -->
                                <ul class="list-unstyled social-rate">
                                    <li>
                                        <i class="fa fa-thumbs-up"></i>
                                        <span class="likes">40</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-comments"></i>
                                        <span class="comments">24</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-share-alt"></i>
                                        <span class="share">14</span>
                                    </li>
                                    <li>
                                        <img src="images/deel.png" alt="">
                                        <span class="deeels">7</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- short description -->
                            <div class="itm-desc line-clamp">
                                <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                            </div>
                            <!-- Addition Info -->
                            <div class="ad-btns">
                                <ul>
                                    <li>
                                        <a href="#"><img src="images/pub.png" alt="">Publish</a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="images/sav.png" alt=""> save</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="input-group post-comment">
                             <span class="input-group-addon" id="basic-addon1">
                               <a href="#" class="submit-comment"><i class="fa fa-comments"></i></a>
                             </span>
                                <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <!-- Ad Box End -->
                    </div>
                </div>
                <div class="item col-md grid-sizer grid-item">
                    <div class="clearfix">
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object" src="images/profile.png" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading logo-name">ibrahim elmajed</h6>
                                <p class="date">23/12/2018<span class="time" style="margin-left: 10px;">23:00</span></p>
                            </div>
                        </div>
                        <h5 class="item-title">
                            <a href="#">a recent company for trading</a>
                        </h5>
                        <!-- Ad Box -->
                        <div class="category-grid-box">
                            <!-- Ad Img -->
                            <div class="category-grid-img">
                                <div class="itm-overlay-top"></div>
                                <div class="itm-overlay-bott"></div>
                                <img class="img-responsive" alt="" src="images/asas.png">
                                <span class="itm-views"><i class="fa fa-eye"></i> 250</span>
                                <span class="itm-from"><img src="icons/4.png" alt=""></span>
                                <span class="itm-price">1000000$</span>
                                <a href="" class="view-details">View Details</a>
                            </div>
                            <!-- Ad Img End -->
                            <div class="short-description">
                                <!-- Ad Category -->
                                <div class="category-title">
                                <span>
                                  <a href="#" class="cat-first">real estate </a>
                                  <a href="#">real estate </a>
                                </span>
                                </div>
                                <!-- no of social interactions -->
                                <ul class="list-unstyled social-rate">
                                    <li>
                                        <i class="fa fa-thumbs-up"></i>
                                        <span class="likes">40</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-comments"></i>
                                        <span class="comments">24</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-share-alt"></i>
                                        <span class="share">14</span>
                                    </li>
                                    <li>
                                        <img src="images/deel.png" alt="">
                                        <span class="deeels">7</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- short description -->
                            <div class="itm-desc line-clamp">
                                <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                            </div>
                            <!-- Addition Info -->
                            <div class="ad-btns">
                                <ul>
                                    <li>
                                        <a href="#"><img src="images/pub.png" alt="">Publish</a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="images/sav.png" alt=""> save</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="input-group post-comment">
                             <span class="input-group-addon" id="basic-addon1">
                               <a href="#" class="submit-comment"><i class="fa fa-comments"></i></a>
                             </span>
                                <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <!-- Ad Box End -->
                    </div>
                </div>
                <div class="item col-md grid-sizer grid-item">
                    <div class="clearfix">
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object" src="images/profile.png" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading logo-name">ibrahim elmajed</h6>
                                <p class="date">23/12/2018<span class="time" style="margin-left: 10px;">23:00</span></p>
                            </div>
                        </div>
                        <h5 class="item-title">
                            <a href="#">a recent company for trading</a>
                        </h5>
                        <!-- Ad Box -->
                        <div class="category-grid-box">
                            <!-- Ad Img -->
                            <div class="category-grid-img">
                                <div class="itm-overlay-top"></div>
                                <div class="itm-overlay-bott"></div>
                                <img class="img-responsive" alt="" src="images/1.jpg">
                                <span class="itm-views"><i class="fa fa-eye"></i> 250</span>
                                <span class="itm-from"><img src="icons/4.png" alt=""></span>
                                <span class="itm-price">1000000$</span>
                                <a href="" class="view-details">View Details</a>
                            </div>
                            <!-- Ad Img End -->
                            <div class="short-description">
                                <!-- Ad Category -->
                                <div class="category-title">
                                <span>
                                  <a href="#" class="cat-first">real estate </a>
                                  <a href="#">real estate </a>
                                </span>
                                </div>
                                <!-- no of social interactions -->
                                <ul class="list-unstyled social-rate">
                                    <li>
                                        <i class="fa fa-thumbs-up"></i>
                                        <span class="likes">40</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-comments"></i>
                                        <span class="comments">24</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-share-alt"></i>
                                        <span class="share">14</span>
                                    </li>
                                    <li>
                                        <img src="images/deel.png" alt="">
                                        <span class="deeels">7</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- short description -->
                            <div class="itm-desc line-clamp">
                                <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                            </div>
                            <!-- Addition Info -->
                            <div class="ad-btns">
                                <ul>
                                    <li>
                                        <a href="#"><img src="images/pub.png" alt="">Publish</a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="images/sav.png" alt=""> save</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="input-group post-comment">
                             <span class="input-group-addon" id="basic-addon1">
                               <a href="#" class="submit-comment"><i class="fa fa-comments"></i></a>
                             </span>
                                <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <!-- Ad Box End -->
                    </div>
                </div>
                <div class="item col-md grid-sizer grid-item">
                    <div class="clearfix">
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object" src="images/profile.png" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h6 class="media-heading logo-name">ibrahim elmajed</h6>
                                <p class="date">23/12/2018<span class="time" style="margin-left: 10px;">23:00</span></p>
                            </div>
                        </div>
                        <h5 class="item-title">
                            <a href="#">a recent company for trading</a>
                        </h5>
                        <!-- Ad Box -->
                        <div class="category-grid-box">
                            <!-- Ad Img -->
                            <div class="category-grid-img">
                                <div class="itm-overlay-top"></div>
                                <div class="itm-overlay-bott"></div>
                                <img class="img-responsive" alt="" src="images/asas.png">
                                <span class="itm-views"><i class="fa fa-eye"></i> 250</span>
                                <span class="itm-from"><img src="icons/4.png" alt=""></span>
                                <span class="itm-price">1000000$</span>
                                <a href="" class="view-details">View Details</a>
                            </div>
                            <!-- Ad Img End -->
                            <div class="short-description">
                                <!-- Ad Category -->
                                <div class="category-title">
                                <span>
                                  <a href="#" class="cat-first">real estate </a>
                                  <a href="#">real estate </a>
                                </span>
                                </div>
                                <!-- no of social interactions -->
                                <ul class="list-unstyled social-rate">
                                    <li>
                                        <i class="fa fa-thumbs-up"></i>
                                        <span class="likes">40</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-comments"></i>
                                        <span class="comments">24</span>
                                    </li>
                                    <li>
                                        <i class="fa fa-share-alt"></i>
                                        <span class="share">14</span>
                                    </li>
                                    <li>
                                        <img src="images/deel.png" alt="">
                                        <span class="deeels">7</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- short description -->
                            <div class="itm-desc line-clamp">
                                <p class="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                            </div>
                            <!-- Addition Info -->
                            <div class="ad-btns">
                                <ul>
                                    <li>
                                        <a href="#"><img src="images/pub.png" alt="">Publish</a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="images/sav.png" alt=""> save</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="input-group post-comment">
                             <span class="input-group-addon" id="basic-addon1">
                               <a href="#" class="submit-comment"><i class="fa fa-comments"></i></a>
                             </span>
                                <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <!-- Ad Box End -->
                    </div>
                </div>
            </div>


            <!-- Row End -->
        </div>
        <!-- Main Container End -->
    </section>

</div>
<!-- Main Content Area End -->

@endsection

