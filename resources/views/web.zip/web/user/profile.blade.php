@extends('web.layouts')

@section('content')
    <section class="profile-banner">
        <div class="container">
            <div class="my-media">
                <div class="logo-img">
                    <a href="#">
                        <img src="{{img($user->image,'users')}}" alt="">
                    </a>
                </div>
                <div class="profile-data">
                    <h4>{{$user->fullname}}</h4>
                    {{--<p class="user-slog">creative director</p>--}}
                    <p class="date-signed">{{$user->created_at->diffForHumans()}}</p>
                    {{--25 Apr 2018--}}
                </div>
            </div>
            @if(!empty($user->interisted_categories))
                <div class="right-links menu-list-items">

                    <ul class="menu-links profile-hover" style="max-height: 400px; ">

                        <li class="dropdown hoverTrigger">
                            <a href="#" class="dropdown-toggle open-catg" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-bars"></i> my categories<i class="fa fa-angle-down fa-indicator"></i>
                                <div class="mobileTriggerButton"></div></a>
                            <ul class="dropdown-menu drop-down-multilevel effect-expand-top" id="urgent" style="transition: all 400ms ease;">
                                @foreach($user->categories as $row)
                                    <li><a target="_blank" href="{{route('web.item.category',$row->{'slug_'.\DataLanguage::get()} )}}">{{$row->{'name_'.\DataLanguage::get()} }}</a></li>
                                @endforeach
                            </ul>
                        </li>
                    </ul>
                </div>
            @endif
        </div>
    </section>

    <!-- =-=-=-=-=-=-= Main Content Area =-=-=-=-=-=-= -->
    <div class="main-content-area reset clearfix view-profile">

        <!-- =-=-=-=-=-=-= Featured Ads =-=-=-=-=-=-= -->
        <section class="custom-padding">
            <!-- Main Container -->
            <div class="container menu-list-items">

                <!-- Row -->
                <div class="row">
                    <!-- Middle Content Box -->

                    @if($auth == true)
                        <div class="col-md-3 col-sm-12 col-xs-12">
                            <div class="user-profile" id="profile_menu">
                                <ul>
                                    <li @if(request()->segment(2) == 'edit-profile') class="active" @endif ><a  href="{{route('web.user.edit-profile')}}">{{__('Profile')}}</a></li>
                                    <li  @if(request()->segment(2) == 'my-items') class="active" @endif ><a  href="{{route('web.user.myitems')}}">{{__('My Items')}}</a></li>
                                    <li  @if(request()->segment(2) == 'add-items') class="active" @endif ><a  href="{{route('web.user.add-items')}}">{{__('Add New Item')}}</a></li>
                                    <li><a href="archives.html">statics</a></li>
                                    <li><a href="#">mail</a></li>
                                    <li><a href="messages.html">Messages</a></li>

                                </ul>
                            </div>
                        </div>

                    @endif

                    <div class="@if($auth == true) col-md-9 @else col-md-12  @endif col-xs-12 col-sm-12">
                        <div class="rows grid" id="items">


                        </div>
                    </div>
                    <!-- Middle Content Box End -->
                </div>


                <!-- Row End -->
            </div>
            <!-- Main Container End -->
        </section>


        <!-- Main Content Area End -->


        </section>
    </div>
@endsection


@section('footer')


    <script>
        $(document).ready(function(){

            runGetItems();

        });

        function runGetItems(){
            $("#loading").show();

            $.get("{{url()->full()}}",{'getData':true,'offset':$("#items .item").length}, function( items ) {
                if(items.status == true){
                    //  console.log(items);
                    for(var i =0;i<= items.data.length;i++){
                        var item = items.data[i];
                        //  console.log(item);
                        $("#items").append(item);
                    }
                    $("#loading").hide();
                }else{
                    $("#loading").html("{{__("No More Items")}}");
                }
            },'json');
        }


        // extension:
        $.fn.scrollEnd = function(callback, timeout) {
            $(this).scroll(function(){
                var $this = $(this);
                if ($this.data('scrollTimeout')) {
                    clearTimeout($this.data('scrollTimeout'));
                }
                $this.data('scrollTimeout', setTimeout(callback,timeout));
            });
        };

        // how to call it (with a 1000ms timeout):
        $(window).scrollEnd(function(){
            runGetItems()
        }, 1000);
    </script>

@endsection